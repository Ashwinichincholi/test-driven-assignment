import { userInfo } from 'os';
import React, { useState } from 'react';

let LoginForm = () =>{

    let [state, setState] =  useState( {
        user:{
            username : '',
            password : ''

        }
    });
    let { user } = state;

    let changeUsername = (event:any) =>{
        setState((state:any) => ({
            user : {
          ...state.user,
username: event.target.value
        }
    
    }));

    };
    
 let changePassword = (event:any) =>{
        setState((state:any) => ({
            user : {
          ...state.user,
password: event.target.value
        }
     }));
    }; 
    let submitLogin = (event:any) => {
        event.preventDefault();
        console.log(user);
    };
 return (
    <React.Fragment>
       <div className='container mt-3'>
        <div className="row">
            <div className="col-md-3">
                <div className="card">
                    <div className="card-header bg-success text-white">
                        <p className="h4">Login Here</p>

                    </div>
                    <div className="card-body bg-light">
                        <form onSubmit={submitLogin}>
                            <div className="mb-3">
                                
                               
                                <input 
                                 value={user.username}
                                 onChange={changeUsername}
                                type="text" className="form-control" placeholder="Username"/>
                                </div>

                                <div className="mb-3">
                                <input 
                                value={user.password}
                                onChange={changePassword}
                                type="password" className="form-control" placeholder="Password"/>
                                </div>
                                <div className="mb-3">
                                <input type="submit" className="btn btn-success btn-sm" value="Login"/>
                                </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
       </div>
    </React.Fragment>
)
};
export default LoginForm;

function value(value: any, arg1: (state: any) => { user: any; }) {
    throw new Error('Function not implemented.');
}
