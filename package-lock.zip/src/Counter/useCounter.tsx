import {useState, useCallback } from 'react';

const useCounter = () => {
    const[counter, setCounter ] = useState(0);
    const increment = useCallback( () => setCounter((value) =>value + 1),[]);
    const decrement = useCallback( () => setCounter((value) =>value - 0),[]);
    return { counter, increment, decrement}
}
export default useCounter;