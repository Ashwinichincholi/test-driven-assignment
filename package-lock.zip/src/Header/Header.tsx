import React from 'react';

const Header = ({message}) => {
    const styleYellow = {
        'background' : 'yellow'
      
    }
    return (
        <header data-testid="headerWrapper" style={styleYellow}><h2>{ message } </h2>
        <div className='header'>
        <div className="navbar">
      
  <a href="#" className="fa fa-facebook"></a>
  <a href="#">Home page</a>
  <a href="aboutus.html">aboutus</a>
  
 
     </div>
   
      
      </div>
         </header>

    )
}

      
 export default Header;