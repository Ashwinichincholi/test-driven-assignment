import { render, screen, waitFor } from '@testing-library/react';
import CreateList from '../CreateList';
import axios from "axios";
import MockAdapter from "axios-mock-adapter";


let mock : MockAdapter;
beforeEach(() => {
mock = new MockAdapter(axios);
})

afterEach(
    () => mock.reset()
)
test("should render successfully list of all records", async () => {
const mockData = [{ id: 1}];
const URL = 'https://jsonplaceholder.typicode.com/todos/';
mock.onGet(URL).reply(200,mockData);
render(<CreateList />);
await waitFor(() => { return screen.findAllByRole("listitem") });
const listing = await screen.findAllByRole("listitem");

expect(listing.length).toBe(mockData.length);
})

test("should throw error 404", async ()=> {
    const mockData = [{ id : 1}];
    const URL = 'https://jsonplaceholder.typicode.com/todos/';
    mock.onGet(URL).reply(404,mockData);
    render(<CreateList />);
    await waitFor( async () => { expect(await screen.findByTestId("error")).toBeInTheDocument() });
})

//test("should render Loading... in the document", async () => {
  //  const mockData = [{ id: 1}];
   // const URL = 'https://jsonplaceholder.typicode.com/todos/';
   // mock.onGet(URL).reply(404,mockData);
   // render(<CreateList />);
   // await waitFor( async() => { expect( await screen.findByTestId("loading")).toBeInTheDocument() });
  // })