import {useState} from 'react';
export default function Listing({list}) {

   
    return <ul>
        {
            list && list.map((item, index) => {
               
                return <li className="xyz" style={{color:'red'}}key={index}>
                   <h1 style={{color: "orange"}}>Hello Style!</h1>
      
                    <span style={{fontWeight: 'bold'}}>{item}</span></li>
      
            })
        }
        <p style={{backgroundColor:"pink"}}>Lorem ipsum dolor sit amet, consectetur
         adipisicing elit. Eligendi non quis exercitationem culpa nesciunt nihil 
         aut nostrum explicabo reprehenderit
         optio amet ab temporibus asperiores quasi cupiditate. Voluptatum ducimus voluptates voluptas?</p>
    </ul>
}
