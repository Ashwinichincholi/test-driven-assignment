import { useEffect, useState } from "react";



const Users = () => {

    const [users, setUsers ] = useState([]);
    const [ error, setError] = useState(null);

    async function fetchData(){
        try{
            const users = await fetch("https://jsonplaceholder.typicode.com/users")
            .then((response) => {
           
                return response.json()

            })
            .then((response) =>{
                return response.map((person:any)=>{
                    return person.name
                }) 
            })
            setUsers(users);

        }
        catch(error:any){
            setError(error);
        }
    }
    useEffect(()=>{
        fetchData();

    },[])
    return <Listing1 items={users}></Listing1>
}
const Listing1 = (props: any) => {
    const { items } = props;
    if (items && items.length > 0) {
        return items.map((item:any, index:number)=>{
            return <ListItem content={item} key={index}/>
        })
    }
    else{
        return <h2>No items found</h2>
    }
}
const ListItem = (props: any) => {
    const { content } = props;
  

    return <li>{content}</li>
}

const Button = (props:any) => {
    const { content1 } = props;
    return <li><button>click here</button></li>

}
export {
Users,
Listing1,
Button
} 