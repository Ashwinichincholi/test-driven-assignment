import React, {useState } from 'react';

const DisplayMessage = () => {
    const [message , setMessage] = useState(null);
    const changeHandler = (e : any) => {
        setMessage(e.target.value)
    }
return(

    <>
    <input type="text" onChange={(e) =>changeHandler(e)}/>
    <div>{message}</div>
    </>
)

}
export default DisplayMessage;