import { useContext } from "react";
import { UserContext } from "../Context/User"; 

export default function UserProfile() {
    const { name } = useContext(UserContext)
    return <p> { name }</p>
}