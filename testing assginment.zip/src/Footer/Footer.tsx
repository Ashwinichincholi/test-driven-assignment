const Footer = () => {
  const styleBlue = {
    'background' : 'blue'
  }
    return (
        <footer className="footerWrapper" style={styleBlue}>
               
      <a  href="aboutus.html">aboutus</a>
        <a href='#'>Contact us</a>
        <a href='#'>T&C</a>
        <a href='#'>Home</a>
        </footer>
    )
}
export default Footer;