import React from 'react';
import { getByText, render, screen, waitFor } from '@testing-library/react';
import Counter from "../Counter";
import userEvents from "@testing-library/user-event";
test("should button click", () =>{
    const spy = jest.spyOn(global, "fetch");
    render (<Counter/>);

    const button = screen.getByRole("button");
    userEvents.click(button);
    expect(spy).toHaveBeenCalled();
  
})
test("should throw  error", async () => {

    const spy = jest.spyOn(global, "fetch").mockImplementation(
        function(url, options){
            return Promise.reject({
            ok:false,
            status: 404,
            json: async () => ({ message : 'not authorized...'})
        
    
});
})
render(<Counter/>);
const button = screen.getByRole("button");
userEvents.click(button);

await waitFor ( async() => {
    expect( await screen.findByText("Error")).toBeInTheDocument();


})
expect(spy).toHaveBeenCalled();

spy.mockRestore();

})