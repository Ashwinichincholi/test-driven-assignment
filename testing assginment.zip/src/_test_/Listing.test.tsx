import { Users } from "../Listing1";
import {render, screen, fireEvent, waitFor } from "@testing-library/react";

test("check user component is render with items", async () => {
    render(<Users />)
  await waitFor(async () => {
      expect(await screen.findByText("leanne graham")).toBeInTheDocument();
   })
})

//here i am getting timed out error neha
