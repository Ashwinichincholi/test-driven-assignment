import { UserProvider } from "../Context/User";
import  UserProfile from "../User/UserProfile";
import { render, screen } from "@testing-library/react";

test("Test username is shown using default context value", async function(){
    render(<UserProvider>
        <UserProfile/>
    </UserProvider>)
    expect ( await screen.findByText("harsh")).toBeInTheDocument();
})

