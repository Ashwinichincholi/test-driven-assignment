import React from 'react';
import Footer from '../Footer/Footer';
import { render, screen } from '@testing-library/react';

it('render Footer component', () => {

    render(<Footer />);
})

it ('should renders a tag', () =>{
   render(<Footer />);
    const Link = screen.getAllByRole('link');
    expect(Link.length).toBe(4);

})


it ('should have href aboutus.html', () => {
    render(<Footer />);
    const text = screen.getByText('aboutus');
    expect(text).toBeInTheDocument();
  })

  it ('should have classname', () => {
    render(<Footer />);
    const text = screen.getByRole('contentinfo');
    expect(text).toHaveClass('footerWrapper');
  })
  
  test('create a snapshot', () => {
    const { container } = render(<Footer/>);
    expect(container.textContent).toMatchSnapshot()
})
