import add from  '../addNumbers';

test(('test add numbers'), () => {
    const result = add(1,2);
    expect(result).toBe(3);
})