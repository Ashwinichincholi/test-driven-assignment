import { render, screen,within } from '@testing-library/react';
import Listing from '../List/Listing';


const MOCK_NAMES = ['apple', 'kiwi', 'grapes'];
test('should render  matching count of items', () =>{
render(<Listing list={MOCK_NAMES}/>);
const items = screen.getAllByRole("listitem");
expect(items.length).toBe( MOCK_NAMES.length)
});

test ('should render matching content of items', () =>{
    render (<Listing list={MOCK_NAMES} />);


screen.getAllByRole("listitem").map((item, index) => {
    return within(item).getByText(MOCK_NAMES[index])
})

.forEach(function(item){
    expect(item).toBeInTheDocument();
})
})
test('create a snapshot', () => {
    const { container } = render(<Listing list={MOCK_NAMES}/>);
    expect(container.firstChild).toMatchSnapshot()
})