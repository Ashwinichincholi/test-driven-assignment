import React from 'react';
import Header from '../Header/Header';
import { render, screen } from '@testing-library/react';



it('renders Header component', () => {
const text="welcome";
render(<Header message={text}/>);
})

//it('renders Get your Quote', () => {

  //  render(<Header />);
    //const text = screen.getByText('Get your Quote');
    //expect(text).toBeInTheDocument();

//})
it ('should have href aboutus.html', () => {
  render(<Header />);
  const text = screen.getByText('aboutus');
  expect(text).toBeInTheDocument();
})

it('it should render H2 tag', () => {

 const text = "welcome";
 render (<Header message={text}/>);
 const heading = screen.getByRole('heading', {level:2});
 expect(heading).toBeInTheDocument();
})
 it('should have style',()=>{
  const text = "Welcome";
  render(<Header message={text}/>);
  const heading = screen.getByTestId('headerWrapper');
  expect(heading).toHaveStyle('background:yellow');
 })
 

 test('create a snapshot', () => {
  const { container } = render(<Header message/>);
  expect(container.textContent).toMatchSnapshot();
})


