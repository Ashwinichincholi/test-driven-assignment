import React from 'react';
import LoginForm from '../Login/LoginForm';
import { render, screen } from '@testing-library/react';


it('render Login component', () => {

    render(<LoginForm />);
    const text = screen.getByText('Login');
  expect(text).toBeInTheDocument();
})