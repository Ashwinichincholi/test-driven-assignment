import { useState } from 'react';

const Counter = () => {
    const [ count,setCounter ] = useState(0);
    const  [ error,setError ] = useState(false);

    async function updateCounter(){
        setCounter(count+1)
        try{
            await fetch("/counter", { method :"post", body: JSON.stringify({count})})
        }
        catch(error){
            setError(true)
        }
        
    }
    if(error){
        return <p>Error</p>
    }
    return <button onClick={updateCounter}>Click</button>
}
export default Counter;