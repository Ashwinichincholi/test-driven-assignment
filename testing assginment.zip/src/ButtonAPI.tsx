import React, { useState, useEffect } from "react";

import axios from 'axios';



const ButtonAPI : React.FC = () =>

{

    const [quotes, setQuote] = useState("");

    const [error, setError] = useState(false);

    const URL = 'https://jsonplaceholder.typicode.com/todos/1';



    async function getQuotesData(){

        try{

            const response = await axios.get(URL);

            const qt = JSON.stringify(response.data);

            const obj = JSON. parse(qt);

            setQuote(obj.title);

        }

        catch(err:any){

            setError(err);

        }

    }

        return <div>

                    <ul><li>{quotes}</li></ul>  <br></br>
                  
                    <button onClick={getQuotesData}>Get Quotes Data</button>

                </div>;

}



export default ButtonAPI;