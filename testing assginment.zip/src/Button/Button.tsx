import { useState } from 'react';

const Button = () => {
  const [isClicked, setIsClicked] = useState (false);

  const clickHandler = () => {
    setIsClicked(true);
  }
  return (
    <div className='snap1'>
    <button style={{ backgroundColor: isClicked ? 'red' : 'blue'}} onClick={clickHandler}>click Here</button>
    </div>
  )

}


export default Button;