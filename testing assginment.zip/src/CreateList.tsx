import React, { useState, useEffect } from "react";
import axios from 'axios';
const CreateList : React.FC = () => {
const [data, setData ] = useState([]);
const [error, setError] = useState(null);
const URL = 'https://jsonplaceholder.typicode.com/todos/';
useEffect(() => {
makeAxiosCall()
})

const makeAxiosCall = async () => {
    try{
        const response = await axios.get(URL);
        setData(response.data);
    }
    catch (err: any){
        setError(err);
    }
}

const makeList = () => {
return data.map((value : any, index) => {
return <li key={value.id}>{value.id}</li>
})
}

if(error != null){
    return <p data-testid="error">Error</p>
}

if(data.length === 0) {
return <p>Loading...</p>
}
return (
<ul>{ data && makeList() }</ul>
)
}
export default CreateList;