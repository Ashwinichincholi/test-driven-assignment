import React from 'react';
import logo from './logo.svg';
import './App.css';
import Header from './Header/Header';
import Footer from './Footer/Footer';

import Listing from './List/Listing';
import ButtonAPI from './ButtonAPI';
import LoginForm from './Login/LoginForm';
import { Listing1 } from './Listing1';
import Hooks from './Hooks';






const names = ['ashu','anju','mary'];

function App() {
  return (
    <div className="App">
      <header className="App-header">
       
       
        <a
          className="App-link"
         
          target="_blank"
          rel="noopener noreferrer"
        >
    
        </a>
    
      </header>
    
    
 
   
      <Header/>
      learn react
   <LoginForm/>
  
      <Listing list={names}/>
      <Listing1/>
          
      <Hooks/>
      <ButtonAPI/>
      <Footer/>
    </div>
  );
}

export default App;
