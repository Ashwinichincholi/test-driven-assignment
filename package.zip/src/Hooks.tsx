function Hooks(props:any) {
    return <p>Hello, {props.name}</p>;
  }
  
 // const root = ReactDOM.createRoot(document.getElementById('root'));
  const element = <Hooks name="Sara" />;
  //render(element);
  export default Hooks;