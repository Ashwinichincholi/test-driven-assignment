export default function add(a: any, b: any){
    return a + b;
}