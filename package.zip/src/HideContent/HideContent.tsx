import React, {useState } from 'react';

const HideContent = () => {
    const[ isVisible, setVisibility] = useState(true);

    const hide = {
        'display' : 'none'

    }
    const clickHandler = () => {
        setVisibility(!isVisible)

    }
    return (
        <>
        <div data-testid="container"  style={ isVisible ? hide : {} }>Hey hello</div>
        <button onClick={clickHandler}>Click</button>
       
        </>
    )
}
export default HideContent;