import React from 'react';
import Button from '../Button/Button';
import { render, screen ,fireEvent } from '@testing-library/react';


//it ('should have click event',() => {
  //  const clickHandler = jest.fn(); //mocking

    //render (<Button clickHandler={clickHandler}/>);
    //const button = screen.getByRole('button', {name : 'Click Here'});
    //fireEvent.click(button);
    //expect(clickHandler).toHaveBeenCalledTimes(1);
   
//})

it('render button with default color blue', () => {
    render (<Button/>);
    const button = screen.getByRole('button');
    expect(button).toHaveStyle('backgroundColor : blue');
})
it('render button with aftr red color click', () => {
    render (<Button/>);
    const button = screen.getByRole('button');
    fireEvent.click(button);
    expect(button).toHaveStyle('backgroundColor : red');
})
it('render button with aftr red color click', () => {
    render (<Button/>);
    const button = screen.getByRole('button');
    fireEvent.click(button);
    expect(button).toMatchSnapshot();
})


