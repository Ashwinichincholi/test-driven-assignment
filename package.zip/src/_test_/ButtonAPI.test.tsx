import { render, screen, waitFor, fireEvent } from '@testing-library/react';

import ButtonAPI from '../ButtonAPI';

import axios from "axios";

import MockAdapter from "axios-mock-adapter";

import userEvents from "@testing-library/user-event";



let mock : MockAdapter;



beforeEach(() => {

    mock = new MockAdapter(axios);

})



test("should render successfully list of all records", async () =>

{

    const mockData = [{

        "userId": 1,

        "id": 1,

        "title": "delectus aut autem",

        "completed": false

      }];



    const URL = 'https://jsonplaceholder.typicode.com/todos/1';

    const result = mock.onGet(URL).reply(200,mockData);



    render(<ButtonAPI />);



    const button = screen.getByRole("button");

    await userEvents.click(button);



    await waitFor(() => { return screen.findAllByRole("listitem") });

    const listing = await screen.findAllByRole("listitem");

    expect(listing.length).toBe(1);

})