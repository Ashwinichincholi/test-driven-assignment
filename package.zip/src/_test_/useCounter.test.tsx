import  {renderHook} from "@testing-library/react";
import { act } from "react-dom/test-utils";
import useCounter from "../Counter/useCounter";

test('should increment counter', ()=>{
    const { result } =renderHook(()=>useCounter());
    
    act(()=>{
        result.current.increment()
    })
    expect(result.current.counter).toBe(1);
    
})
test('should decrement counter', ()=>{
    const { result }=renderHook(()=>useCounter());
    
    act(()=>{
        result.current.decrement()
    })
    expect(result.current.counter).toBe(0);
    
})


