import React from 'react';
import HideContent from '../HideContent/HideContent';
import { render, screen ,fireEvent} from '@testing-library/react';

it('should hide', () => {
    render(<HideContent />);
    const container = screen.getByTestId('container');
    const btn = screen.getByRole('button');
    fireEvent.click(btn);
    expect(container).toBeVisible();
})
test('create a snapshot', () => {
    const { container } = render(<HideContent/>);
    expect(container.click).toMatchSnapshot()
})