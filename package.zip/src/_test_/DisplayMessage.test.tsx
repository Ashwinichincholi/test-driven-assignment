import DisplayMessage from '../DisplayMessage/DisplayMessage';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

test('onChange event', async () => {
    const message = "hey this testing seession";
    render(<DisplayMessage />);
    const inputBox = screen.getByRole('textbox');
    await userEvent.type(inputBox,message);
    expect(screen.getByRole('textbox')).toHaveValue(message);
})