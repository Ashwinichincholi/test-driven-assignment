import React, { useState, createContext } from 'react';

interface UserContext {
    name: String
}

const UserContext = createContext<UserContext>({name : "" })
const { Provider } = UserContext;
UserContext.displayName = 'React'


const UserProvider = function ({ children } : any) {

    const [name, setName ] = useState("harsh");
    function updateUser(name : string){
        setName(name);
    }

    return <Provider value={{ name, updateUser}}>
        { children }
        </Provider>
}

export { UserProvider , UserContext }